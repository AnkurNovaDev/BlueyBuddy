# Oppo A3s / Android 8.1 — physical-device test checklist

Yeh checklist actual phone par APK install hone ke baad run karein. Har item pass/fail mark karein; koi fail ho to exact step aur log save karein.

## Build and install

- [ ] Latest `BlueyBuddy-debug-apk` artifact `app-debug.apk` install hota hai.
- [ ] Clean install aur upgrade install dono test hue.
- [ ] App launch par crash nahi hota.
- [ ] Android/ColorOS version aur available RAM record ki.

## Permissions and owner security

- [ ] PIN setup aur confirmation kaam karta hai.
- [ ] Wrong PIN local timestamp log mein add hota hai.
- [ ] Repeated failures par cooldown lagta hai aur cooldown ke dauran PIN dialog access block hota hai.
- [ ] AndroidX biometric prompt sirf tab aata hai jab device standard biometric provider report kare.
- [ ] Oppo A3s par fingerprint reader nahi hai; PIN fallback verify karein.
- [ ] ColorOS Face Unlock ko app ka standard biometric prompt access karta hai ya nahi, separately test karein; integration assume na karein.
- [ ] Overlay permission grant/return works.
- [ ] Microphone permission allow/deny flows work.
- [ ] Accessibility service manually enable karne ke baad status `Enabled` dikhata hai.

## Orb, pill, background

- [ ] Orb Home screen aur doosre app ke upar visible hai.
- [ ] Eyes blink karti hain; smile visible hai; animation stutter/battery drain note karein.
- [ ] Orb left/right drag hota hai aur nearest edge par dock karta hai.
- [ ] Tap se top pill smoothly open hoti hai.
- [ ] Close button pill ko hata kar orb wapas dikhata hai.
- [ ] Main screen Stop action aur notification ka Stop action service ko band karte hain.
- [ ] App switching, screen lock/unlock, screen rotation aur 15–30 minute use ke baad service behavior note karein.
- [ ] ColorOS battery optimization ka impact note karein.

## Voice, commands and offline behavior

- [ ] Hold mic, `time batao`, release: result text aur voice mein aata hai.
- [ ] `Aaj ki date` local date bolta hai.
- [ ] `paanch minute timer`: confirmation aati hai; notification/speech completion par aata hai.
- [ ] `cancel timer`: pending timer cancel karta hai.
- [ ] Service stop/process recreation par pending timer notification test karein.
- [ ] Timer set karke phone reboot karein; boot complete aur device unlock ke baad BootReceiver pending deadline reschedule kare aur notification deadline par aaye.
- [ ] `2 plus 3`, `10 minus 4`, `6 times 7`, `8 divide 2` offline answer dete hain.
- [ ] `Open Settings` aur `Open WhatsApp` (installed ho to) kaam karte hain.
- [ ] `Search for weather` browser search kholta hai.
- [ ] Wi-Fi/mobile data OFF karke Hindi speech recognition test karein; provider offline model hai ya nahi record karein.
- [ ] TTS Hindi voice available / missing data behavior record karein.

## Accessibility controls

- [ ] Normal text field focus karke `Type hello`; text current cursor/selection par type/paste hota hai.
- [ ] Password/PIN field mein Bluey Buddy text nahi daalta.
- [ ] Selected text `Copy` command se clipboard mein aata hai.
- [ ] Normal editable field mein `Paste` kaam karta hai.
- [ ] Scroll up/down scrollable screen par kaam karta hai.
- [ ] Back aur Home kaam karte hain.
- [ ] Ek secure/custom app mein restriction expected tareeke se respect hoti hai.

## Evidence on failure

- [ ] Exact command/tap sequence
- [ ] Expected vs actual result
- [ ] Android + ColorOS version
- [ ] Accessibility, overlay, mic permissions ka state
- [ ] Speech provider/offline language-pack state
- [ ] GitHub Actions build log, agar APK build ya install fail hua
