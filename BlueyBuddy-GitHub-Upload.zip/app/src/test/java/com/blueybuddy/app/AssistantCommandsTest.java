package com.blueybuddy.app;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class AssistantCommandsTest {
    @Test public void parsesEnglishSeconds() {
        assertEquals(45_000L, AssistantCommands.parseTimerMillis("45 seconds timer"));
    }

    @Test public void parsesMinuteVariants() {
        assertEquals(300_000L, AssistantCommands.parseTimerMillis("5 minute ka timer"));
        assertEquals(180_000L, AssistantCommands.parseTimerMillis("3 min timer"));
    }

    @Test public void parsesHindiMinutesAndDevanagariDigits() {
        assertEquals(240_000L, AssistantCommands.parseTimerMillis("4 मिनट का टाइमर"));
        assertEquals(240_000L, AssistantCommands.parseTimerMillis("४ मिनट का टाइमर"));
    }

    @Test public void parsesSpokenNumberWords() {
        assertEquals(300_000L, AssistantCommands.parseTimerMillis("paanch minute timer"));
        assertEquals(120_000L, AssistantCommands.parseTimerMillis("two minutes timer"));
        assertEquals(120_000L, AssistantCommands.parseTimerMillis("दो मिनट टाइमर"));
        assertEquals(3_600_000L, AssistantCommands.parseTimerMillis("एक घंटा timer"));
    }

    @Test public void parsesHoursAndRejectsOutOfRange() {
        assertEquals(7_200_000L, AssistantCommands.parseTimerMillis("2 hours timer"));
        assertEquals(-1L, AssistantCommands.parseTimerMillis("2000 hours timer"));
    }

    @Test public void rejectsMissingDuration() {
        assertEquals(-1L, AssistantCommands.parseTimerMillis("timer start karo"));
    }

    @Test public void performsOfflineMath() {
        assertEquals("5", CommandParser.calculate("2 plus 3"));
        assertEquals("42", CommandParser.calculate("6 times 7"));
        assertEquals("6", CommandParser.calculate("10 minus 4"));
        assertEquals("12", CommandParser.calculate("3 गुणा 4"));
        assertEquals("5", CommandParser.calculate("2 जोड़ 3"));
        assertEquals("2.5", CommandParser.calculate("5 divide 2"));
        assertEquals("Zero se divide nahi kar sakte.", CommandParser.calculate("8 / 0"));
    }

    @Test public void unsupportedMathDoesNotInventAnswer() {
        assertNull(CommandParser.calculate("tell me a story"));
    }
}
