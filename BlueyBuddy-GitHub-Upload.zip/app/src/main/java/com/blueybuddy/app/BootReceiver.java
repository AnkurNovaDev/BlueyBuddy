package com.blueybuddy.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restores a pending timer after Android finishes booting. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            TimerAlarmReceiver.rescheduleAfterBoot(context);
        }
    }
}
