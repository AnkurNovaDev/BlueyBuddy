package com.blueybuddy.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;
import java.util.concurrent.Executor;

/** Main setup screen for the Bluey Buddy floating assistant. */
public class MainActivity extends FragmentActivity {
    private static final int REQUEST_OVERLAY = 4101;
    private static final int REQUEST_AUDIO = 4102;
    private TextView statusView;
    private boolean ownerVerifiedThisSession;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
        if (!SecurityStore.hasPin(this)) {
            statusView.postDelayed(() -> showPinSetupDialog(null), 450L);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (statusView != null) updateStatus();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(24), dp(20), dp(28));
        page.setBackgroundColor(Color.rgb(247, 251, 255));

        TextView title = new TextView(this);
        title.setText("Bluey Buddy");
        title.setTextSize(30);
        title.setTextColor(Color.rgb(16, 83, 151));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Aapka chhota blue floating assistant");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.rgb(72, 107, 139));
        subtitle.setPadding(0, dp(3), 0, dp(16));
        page.addView(subtitle);

        LinearLayout statusCard = card();
        TextView statusTitle = label("PHONE STATUS");
        statusCard.addView(statusTitle);
        statusView = new TextView(this);
        statusView.setTextSize(13);
        statusView.setTextColor(Color.rgb(34, 67, 96));
        statusView.setPadding(0, dp(8), 0, 0);
        statusCard.addView(statusView);
        page.addView(statusCard, matchWrap());

        addButton(page, "START FLOATING BLUEY", "Screen ke upar blue orb dikhayein.", v -> startAssistant());
        addButton(page, "STOP FLOATING BLUEY", "Floating orb aur voice listener band karein.", v -> stopAssistant());
        addButton(page, "ALLOW DISPLAY OVER OTHER APPS", "Orb ko doosri apps ke upar dikhane ki permission.", v -> requestOverlayPermission());
        addButton(page, "ENABLE PHONE CONTROLS", "Typing, copy/paste aur scroll ke liye Accessibility settings.", v -> openAccessibilitySettings());
        addButton(page, "OWNER PIN / DEVICE BIOMETRIC", "Owner PIN, supported device biometric aur failed unlock log.", v -> ownerGate());
        addButton(page, "TEST VOICE OUTPUT", "Phone ke installed Text-to-Speech engine ko test karein.", v -> testSpeech());
        addButton(page, "HOW TO USE", "Supported voice commands aur limitations dekhein.", v -> showHelp());

        TextView privacy = new TextView(this);
        privacy.setText("PRIVACY\nBluey Buddy mein koi AI API key ya app-side cloud account nahi hai. Commands phone par locally route hoti hain; Google search aur voice recognition phone ke installed browser / speech provider par depend kar sakte hain. Offline voice tabhi chalegi jab device par Hindi offline speech pack installed aur supported ho. App chhupkar photo nahi leti; failed owner unlock ke sirf timestamps local phone par record hote hain.");
        privacy.setTextColor(Color.rgb(79, 104, 128));
        privacy.setTextSize(12);
        privacy.setPadding(dp(4), dp(18), dp(4), 0);
        page.addView(privacy);

        scroll.addView(page);
        setContentView(scroll);
        updateStatus();
    }

    private void startAssistant() {
        if (!SecurityStore.hasPin(this)) {
            showPinSetupDialog(this::startAssistantAfterAuthorization);
            return;
        }
        if (!ownerVerifiedThisSession) {
            authenticateOwner(this::startAssistantAfterAuthorization);
            return;
        }
        startAssistantAfterAuthorization();
    }

    private void startAssistantAfterAuthorization() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission();
            Toast.makeText(this, "Pehle overlay permission allow karein.", Toast.LENGTH_LONG).show();
            return;
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        Intent intent = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
        else startService(intent);
        Toast.makeText(this, "Bluey Buddy orb screen par aa gaya.", Toast.LENGTH_SHORT).show();
    }

    private void stopAssistant() {
        stopService(new Intent(this, OverlayService.class));
        Toast.makeText(this, "Bluey Buddy band kar diya.", Toast.LENGTH_SHORT).show();
    }

    private void requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission pehle se ON hai.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivityForResult(intent, REQUEST_OVERLAY);
    }

    private void openAccessibilitySettings() {
        new AlertDialog.Builder(this)
                .setTitle("Phone controls enable karein")
                .setMessage("Settings khulne par Installed services / Downloaded services mein ‘Bluey Buddy phone controls’ select karke ON karein. Is permission se app focused text field mein wahi text type kar sakti hai jo aap bolenge, aur aapke kehne par scroll/copy/paste kar sakti hai. Isse password ya payment action automate nahi hota.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Open Settings", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                    startActivity(intent);
                }).show();
    }

    private void ownerGate() {
        if (!SecurityStore.hasPin(this)) {
            showPinSetupDialog(this::showSecurityLog);
            return;
        }
        authenticateOwner(this::showSecurityLog);
    }

    private void authenticateOwner(Runnable onSuccess) {
        if (SecurityStore.isLockedOut(this)) {
            long seconds = (SecurityStore.getLockoutRemainingMillis(this) + 999L) / 1000L;
            Toast.makeText(this, "Bahut attempts hue. " + seconds + " seconds baad dobara try karein.", Toast.LENGTH_LONG).show();
            return;
        }
        BiometricManager manager = BiometricManager.from(this);
        if (manager.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS) {
            Executor executor = ContextCompat.getMainExecutor(this);
            BiometricPrompt prompt = new BiometricPrompt(this, executor,
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                            super.onAuthenticationSucceeded(result);
                            ownerVerifiedThisSession = true;
                            SecurityStore.recordSuccessfulVerification(MainActivity.this);
                            if (onSuccess != null) onSuccess.run();
                        }
                        @Override public void onAuthenticationFailed() {
                            super.onAuthenticationFailed();
                            SecurityStore.recordFailedAttempt(MainActivity.this);
                        }
                        @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                            super.onAuthenticationError(errorCode, errString);
                            if (errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON
                                    || errorCode == BiometricPrompt.ERROR_LOCKOUT
                                    || errorCode == BiometricPrompt.ERROR_LOCKOUT_PERMANENT) {
                                verifyPinDialog(onSuccess);
                            }
                        }
                    });
            BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Bluey Buddy owner verification")
                    .setSubtitle("Device biometric available ho to use karein; warna PIN use karein")
                    .setNegativeButtonText("Use PIN")
                    .build();
            prompt.authenticate(info);
        } else {
            verifyPinDialog(onSuccess);
        }
    }

    private void showPinSetupDialog(Runnable onSuccess) {
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(dp(22), dp(10), dp(22), 0);
        EditText first = new EditText(this);
        first.setHint("Naya 4–8 digit PIN");
        first.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        fields.addView(first);
        EditText second = new EditText(this);
        second.setHint("PIN dobara likhein");
        second.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        fields.addView(second);

        new AlertDialog.Builder(this)
                .setTitle("Bluey Buddy owner PIN set karein")
                .setMessage("PIN sirf is phone par secure hash ke roop mein save hota hai.")
                .setView(fields)
                .setCancelable(false)
                .setPositiveButton("Save PIN", (dialog, which) -> {
                    String a = first.getText().toString();
                    String b = second.getText().toString();
                    if (!a.equals(b) || !a.matches("[0-9]{4,8}") || !SecurityStore.savePin(this, a)) {
                        Toast.makeText(this, "PIN match nahi hua. 4–8 digits ka same PIN daalein.", Toast.LENGTH_LONG).show();
                        showPinSetupDialog(onSuccess);
                    } else {
                        ownerVerifiedThisSession = true;
                        SecurityStore.recordSuccessfulVerification(this);
                        Toast.makeText(this, "Owner PIN save ho gaya.", Toast.LENGTH_SHORT).show();
                        if (onSuccess != null) onSuccess.run();
                    }
                })
                .setNegativeButton("Later", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void verifyPinDialog(Runnable onSuccess) {
        if (SecurityStore.isLockedOut(this)) {
            long seconds = (SecurityStore.getLockoutRemainingMillis(this) + 999L) / 1000L;
            Toast.makeText(this, "Security lockout active. " + seconds + " seconds baad try karein.", Toast.LENGTH_LONG).show();
            return;
        }
        EditText input = new EditText(this);
        input.setHint("Owner PIN");
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this)
                .setTitle("Owner PIN verify karein")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Verify", (dialog, which) -> {
                    if (SecurityStore.isLockedOut(this)) {
                        long seconds = (SecurityStore.getLockoutRemainingMillis(this) + 999L) / 1000L;
                        Toast.makeText(this, "Security lockout active. " + seconds + " seconds baad try karein.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (SecurityStore.verifyPin(this, input.getText().toString())) {
                        ownerVerifiedThisSession = true;
                        SecurityStore.recordSuccessfulVerification(this);
                        if (onSuccess != null) onSuccess.run();
                    } else {
                        SecurityStore.recordFailedAttempt(this);
                        long remaining = SecurityStore.getLockoutRemainingMillis(this);
                        String note = remaining > 0
                                ? "Bahut galat attempts hue. " + ((remaining + 999L) / 1000L) + " seconds ka lockout laga hai."
                                : "Verification galat hai. Attempt ka time local log mein save hua.";
                        Toast.makeText(this, note, Toast.LENGTH_LONG).show();
                    }
                }).show();
    }

    private void showSecurityLog() {
        List<String> attempts = SecurityStore.getFailedAttempts(this);
        StringBuilder text = new StringBuilder("Owner verification successful.\n\nFailed PIN / biometric attempts (newest first):\n");
        if (attempts.isEmpty()) text.append("Koi failed owner verification attempt record nahi hua.");
        else for (String item : attempts) text.append("• ").append(item).append('\n');
        text.append("\nNote: yahan sirf timestamps save hote hain; hidden camera/photo capture nahi hota.");
        new AlertDialog.Builder(this).setTitle("Bluey Buddy security log")
                .setMessage(text.toString()).setPositiveButton("OK", null).show();
    }

    private void testSpeech() {
        final android.speech.tts.TextToSpeech[] holder = new android.speech.tts.TextToSpeech[1];
        holder[0] = new android.speech.tts.TextToSpeech(this, status -> {
            android.speech.tts.TextToSpeech engine = holder[0];
            if (status == android.speech.tts.TextToSpeech.SUCCESS && engine != null) {
                int language = engineLanguage(engine);
                engine.speak("Namaste, main Bluey Buddy hoon.", android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "bluey-test");
                Toast.makeText(this, language == android.speech.tts.TextToSpeech.LANG_MISSING_DATA
                        ? "TTS language data check karein." : "Voice output test shuru.", Toast.LENGTH_SHORT).show();
                statusView.postDelayed(engine::shutdown, 10000L);
            } else {
                Toast.makeText(this, "Phone ka Text-to-Speech engine available nahi hai.", Toast.LENGTH_LONG).show();
                if (engine != null) engine.shutdown();
            }
        });
    }

    private int engineLanguage(android.speech.tts.TextToSpeech engine) {
        int result = engine.setLanguage(new java.util.Locale("hi", "IN"));
        if (result == android.speech.tts.TextToSpeech.LANG_MISSING_DATA
                || result == android.speech.tts.TextToSpeech.LANG_NOT_SUPPORTED) {
            result = engine.setLanguage(java.util.Locale.getDefault());
        }
        return result;
    }

    private void showHelp() {
        String help = "FLOATING ORB\n• Blue orb ko drag karein; screen edge par dock ho jayega. Tap karne par top pill panel khulega.\n• Mic button ko dabakar boliye; chhodne par recognition process hota hai.\n\nVOICE COMMANDS\n• ‘Open WhatsApp / YouTube / Settings’\n• ‘Time batao’, ‘Aaj ki date’\n• ‘5 minute ka timer’ / ‘paanch minute timer’ / ‘cancel timer’\n• ‘2 plus 3’, ‘10 minus 4’, ‘6 times 7’ (basic offline calculation)\n• ‘Search for …’ / normal question (browser search)\n• ‘Type …’ (pehle text field select karein)\n• ‘Copy’, ‘Paste’, ‘Scroll down’, ‘Scroll up’, ‘Back’, ‘Home’\n\nLIMITS\n• Voice recognition Android ke Speech Recognition provider par depend hai. EXTRA_PREFER_OFFLINE request bheji jaati hai, lekin offline mode tabhi chalega jab provider mein Hindi offline pack installed ho; app iski guarantee nahi de sakta.\n• App continuous wake-word listening nahi karti; privacy aur battery ke liye mic ko manually hold karna hota hai.\n• Android system biometric tabhi use hota hai jab device AndroidX BiometricPrompt ko expose kare. Oppo A3s mein fingerprint sensor nahi hai; built-in Face Unlock proprietary hai aur is app mein integrate/test nahi hua, isliye PIN ko primary fallback samjhein.\n• Har app ke text field/copy/scroll par Android accessibility restrictions alag ho sakti hain. PIN/payment/password actions automate nahi kiye jaate.";
        new AlertDialog.Builder(this).setTitle("Bluey Buddy kaise use karein")
                .setMessage(help).setPositiveButton("Samajh gaya", null).show();
    }

    private void updateStatus() {
        StringBuilder s = new StringBuilder();
        s.append("Overlay: ").append(Settings.canDrawOverlays(this) ? "Allowed" : "Not allowed").append('\n');
        s.append("Microphone: ").append(ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED ? "Allowed" : "Not allowed").append('\n');
        s.append("Accessibility bridge: ").append(isAccessibilityEnabled() ? "Enabled" : "Not enabled").append('\n');
        s.append("Owner PIN: ").append(SecurityStore.hasPin(this) ? "Set" : "Not set").append('\n');
        s.append("Android biometric provider: ").append(
                BiometricManager.from(this).canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS ? "Available" : "Not enrolled / unavailable").append('\n');
        s.append("Speech recognition provider: ").append(android.speech.SpeechRecognizer.isRecognitionAvailable(this) ? "Available" : "Not available").append('\n');
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            s.append("On-device speech: ").append(android.speech.SpeechRecognizer.isOnDeviceRecognitionAvailable(this) ? "Available" : "Not available").append('\n');
        } else {
            s.append("On-device speech: provider / offline language pack par depend karta hai (Android 8.1)\n");
        }
        s.append("Android version: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(')');
        statusView.setText(s.toString());
    }

    private boolean isAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        ComponentName component = new ComponentName(this, BuddyAccessibilityService.class);
        return enabled.toLowerCase().contains(component.flattenToString().toLowerCase());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startAssistantAfterAuthorization();
            else Toast.makeText(this, "Voice commands ke liye microphone permission zaroori hai.", Toast.LENGTH_LONG).show();
        }
        updateStatus();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY && Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission mil gayi. Ab Start Floating Bluey dabayein.", Toast.LENGTH_LONG).show();
        }
        updateStatus();
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(background(Color.WHITE, dp(18), Color.rgb(222, 237, 250)));
        box.setElevation(dp(2));
        return box;
    }

    private TextView label(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(10);
        v.setTextColor(Color.rgb(82, 123, 162));
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private void addButton(LinearLayout parent, String title, String subtitle, View.OnClickListener listener) {
        LinearLayout item = card();
        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.rgb(19, 92, 161));
        heading.setTextSize(14);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        item.addView(heading);
        TextView note = new TextView(this);
        note.setText(subtitle);
        note.setTextSize(12);
        note.setTextColor(Color.rgb(92, 118, 143));
        note.setPadding(0, dp(4), 0, 0);
        item.addView(note);
        item.setClickable(true);
        item.setFocusable(true);
        item.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = matchWrap();
        lp.bottomMargin = dp(10);
        parent.addView(item, lp);
    }

    private GradientDrawable background(int color, int radius, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
