package com.blueybuddy.app;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.text.InputType;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Optional phone-control bridge. Android requires the user to turn this service on
 * manually in Accessibility settings. It only acts after an explicit spoken command.
 */
public class BuddyAccessibilityService extends AccessibilityService {
    private static volatile BuddyAccessibilityService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public static boolean isEnabled() {
        return instance != null;
    }

    public static boolean typeIntoFocusedField(String value) {
        BuddyAccessibilityService service = instance;
        if (service == null) return false;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (field == null || !field.isEditable() || isPasswordField(field)) return false;

        ClipboardManager clipboard = (ClipboardManager) service.getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            // Paste inserts at the current cursor/selection, matching normal keyboard typing.
            clipboard.setPrimaryClip(ClipData.newPlainText("Bluey Buddy text", value));
            if (field.performAction(AccessibilityNodeInfo.ACTION_PASTE)) return true;
        }

        // Some custom fields reject paste but support ACTION_SET_TEXT. Keep existing text.
        CharSequence old = field.getText();
        String combined = (old == null ? "" : old.toString()) + value;
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, combined);
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    public static boolean copySelection() {
        BuddyAccessibilityService service = instance;
        if (service == null) return false;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
        if (focused != null && !isPasswordField(focused)
                && focused.performAction(AccessibilityNodeInfo.ACTION_COPY)) return true;
        focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        return focused != null && !isPasswordField(focused)
                && focused.performAction(AccessibilityNodeInfo.ACTION_COPY);
    }

    public static boolean pasteClipboard() {
        AccessibilityNodeInfo focused = focusedNode();
        return focused != null && focused.isEditable() && !isPasswordField(focused)
                && focused.performAction(AccessibilityNodeInfo.ACTION_PASTE);
    }

    public static boolean scroll(boolean down) {
        BuddyAccessibilityService service = instance;
        if (service == null) return false;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return false;

        Deque<AccessibilityNodeInfo> stack = new ArrayDeque<>();
        stack.push(root);
        while (!stack.isEmpty()) {
            AccessibilityNodeInfo node = stack.pop();
            if (node.isScrollable()) {
                int action = down ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                        : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD;
                if (node.performAction(action)) return true;
            }
            for (int i = node.getChildCount() - 1; i >= 0; i--) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) stack.push(child);
            }
        }
        return false;
    }

    public static boolean goBack() {
        BuddyAccessibilityService service = instance;
        return service != null && service.performGlobalAction(GLOBAL_ACTION_BACK);
    }

    public static boolean goHome() {
        BuddyAccessibilityService service = instance;
        return service != null && service.performGlobalAction(GLOBAL_ACTION_HOME);
    }

    private static AccessibilityNodeInfo focusedNode() {
        BuddyAccessibilityService service = instance;
        if (service == null) return null;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return null;
        AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (focused != null) return focused;
        return root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
    }

    private static boolean isPasswordField(AccessibilityNodeInfo node) {
        if (node == null) return true;
        if (node.isPassword()) return true;
        int variation = node.getInputType() & InputType.TYPE_MASK_VARIATION;
        return variation == InputType.TYPE_TEXT_VARIATION_PASSWORD
                || variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                || variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
                || variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD;
    }
}
