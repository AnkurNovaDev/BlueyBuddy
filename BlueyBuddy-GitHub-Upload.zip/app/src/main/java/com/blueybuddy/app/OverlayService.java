package com.blueybuddy.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

import java.util.ArrayList;
import java.util.Locale;

/** Floating Bluey orb + voice panel. Runs only after the user starts it from the app. */
public class OverlayService extends Service implements TextToSpeech.OnInitListener {
    private static final String CHANNEL_ID = "bluey_buddy_running";
    private static final int NOTIFICATION_ID = 2107;
    private static final String ACTION_STOP = "com.blueybuddy.app.action.STOP_ASSISTANT";

    private WindowManager windowManager;
    private WindowManager.LayoutParams orbParams;
    private WindowManager.LayoutParams pillParams;
    private OrbView orbView;
    private LinearLayout pillView;
    private TextView messageView;
    private Button micButton;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady;
    private CountDownTimer timer;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        tts = new TextToSpeech(this, this);
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            } else {
                // Older Android versions rely on the installed recognizer provider.
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            }
            recognizer.setRecognitionListener(new BuddyRecognitionListener());
        }
        if (android.provider.Settings.canDrawOverlays(this)) {
            addOrb();
            long deadline = TimerAlarmReceiver.getDeadline(this);
            long remaining = deadline - System.currentTimeMillis();
            if (remaining > 0L) startTimer(remaining);
        } else stopSelf();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onInit(int status) {
        ttsReady = status == TextToSpeech.SUCCESS;
        if (ttsReady && tts != null) {
            int result = tts.setLanguage(new Locale("hi", "IN"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.getDefault());
            }
            tts.setSpeechRate(0.96f);
        }
    }

    private void addOrb() {
        if (orbView != null) return;
        orbView = new OrbView();
        int size = dp(66);
        orbParams = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        orbParams.gravity = Gravity.TOP | Gravity.START;
        orbParams.x = Math.max(0, getResources().getDisplayMetrics().widthPixels - size - dp(8));
        orbParams.y = getResources().getDisplayMetrics().heightPixels / 2;
        try {
            windowManager.addView(orbView, orbParams);
        } catch (Exception e) {
            orbView = null;
            stopSelf();
        }
    }

    private void showPill() {
        if (pillView != null) {
            pillView.setVisibility(View.VISIBLE);
            return;
        }
        if (orbView != null) orbView.setVisibility(View.INVISIBLE);

        pillView = new LinearLayout(this);
        pillView.setOrientation(LinearLayout.VERTICAL);
        pillView.setPadding(dp(16), dp(10), dp(12), dp(10));
        pillView.setBackground(roundRect(Color.WHITE, dp(33), 0x332D75C7, dp(1)));
        pillView.setElevation(dp(12));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = new TextView(this);
        brand.setText("●  BLUEY BUDDY");
        brand.setTextColor(Color.rgb(18, 98, 177));
        brand.setTextSize(11);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(26), 1f));

        Button close = new Button(this);
        close.setText("×");
        close.setTextSize(19);
        close.setMinWidth(dp(40));
        close.setMinimumWidth(dp(40));
        close.setPadding(0, 0, 0, 0);
        top.addView(close, new LinearLayout.LayoutParams(dp(42), dp(36)));
        close.setOnClickListener(v -> hidePill());
        pillView.addView(top);

        messageView = new TextView(this);
        messageView.setText("Namaste! Mic ko dabakar boliye.");
        messageView.setTextColor(Color.rgb(27, 55, 82));
        messageView.setTextSize(14);
        messageView.setPadding(0, dp(6), 0, dp(8));
        messageView.setMaxLines(4);
        messageView.setVisibility(View.GONE);
        pillView.addView(messageView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        micButton = new Button(this);
        micButton.setText("🎙  DABAKAR BOLEIN");
        micButton.setTextSize(13);
        micButton.setTextColor(Color.WHITE);
        micButton.setAllCaps(false);
        micButton.setBackground(roundRect(Color.rgb(22, 117, 209), dp(18), Color.TRANSPARENT, 0));
        micButton.setVisibility(View.GONE);
        micButton.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                beginListening();
                return true;
            } else if (event.getAction() == MotionEvent.ACTION_UP
                    || event.getAction() == MotionEvent.ACTION_CANCEL) {
                endListening();
                return true;
            }
            return true;
        });
        pillView.addView(micButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44)));

        final LinearLayout targetPill = pillView;
        final int compactSize = dp(66);
        final int fullWidth = getResources().getDisplayMetrics().widthPixels - dp(24);
        final int startX = orbParams == null ? dp(12) : Math.min(Math.max(0, fullWidth - compactSize), Math.max(0, orbParams.x));
        final int startY = orbParams == null ? dp(22) : Math.max(dp(8), orbParams.y);
        final int endX = dp(12);
        final int endY = dp(22);
        pillParams = new WindowManager.LayoutParams(
                compactSize, compactSize,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        pillParams.gravity = Gravity.TOP | Gravity.START;
        pillParams.x = Math.min(startX, Math.max(0, fullWidth - compactSize));
        pillParams.y = startY;
        try {
            windowManager.addView(targetPill, pillParams);
            ValueAnimator morph = ValueAnimator.ofFloat(0f, 1f);
            morph.setDuration(240L);
            morph.addUpdateListener(animation -> {
                if (pillView != targetPill || pillParams == null) return;
                float progress = (float) animation.getAnimatedValue();
                pillParams.width = compactSize + (int) ((fullWidth - compactSize) * progress);
                pillParams.x = (int) (startX + (endX - startX) * progress);
                pillParams.y = (int) (startY + (endY - startY) * progress);
                try { windowManager.updateViewLayout(targetPill, pillParams); } catch (Exception ignored) { }
            });
            morph.addListener(new AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(Animator animation) {
                    if (pillView != targetPill || pillParams == null) return;
                    messageView.setVisibility(View.VISIBLE);
                    micButton.setVisibility(View.VISIBLE);
                    pillParams.width = fullWidth;
                    pillParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
                    pillParams.x = endX;
                    pillParams.y = endY;
                    targetPill.setBackground(roundRect(Color.WHITE, dp(24), 0x332D75C7, dp(1)));
                    try { windowManager.updateViewLayout(targetPill, pillParams); } catch (Exception ignored) { }
                }
            });
            morph.start();
        } catch (Exception e) {
            pillView = null;
            if (orbView != null) orbView.setVisibility(View.VISIBLE);
        }
    }

    private void hidePill() {
        if (pillView != null) {
            try { windowManager.removeView(pillView); } catch (Exception ignored) { }
            pillView = null;
            messageView = null;
            micButton = null;
        }
        if (orbView != null) orbView.setVisibility(View.VISIBLE);
    }

    private void setMessage(String message) {
        if (pillView == null) showPill();
        if (messageView != null) messageView.setText(message);
    }

    private void beginListening() {
        if (recognizer == null) {
            setMessage("Is phone par speech recognition service available nahi hai. Keyboard/browser search use kar sakte hain.");
            return;
        }
        if (android.os.Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            setMessage("Pehle Bluey Buddy ke liye Microphone permission allow karein.");
            return;
        }
        try {
            if (tts != null) tts.stop();
            setMessage("Sun raha hoon… bolna shuru karein.");
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            recognizer.startListening(intent);
            if (micButton != null) micButton.setText("●  SUN RAHA HOON…");
        } catch (Exception e) {
            setMessage("Voice shuru nahi ho paayi. Microphone permission aur speech service check karein.");
        }
    }

    private void endListening() {
        if (recognizer != null) {
            try { recognizer.stopListening(); } catch (Exception ignored) { }
        }
        if (micButton != null) micButton.setText("🎙  DABAKAR BOLEIN");
    }

    private void handleRecognizedText(String text) {
        if (micButton != null) micButton.setText("🎙  DABAKAR BOLEIN");
        if (messageView != null) messageView.setText("Aapne kaha: “" + text + "”\nSoch raha hoon…");
        handler.postDelayed(() -> {
            if (messageView != null) {
                String answer = AssistantCommands.execute(this, text);
                messageView.setText(answer);
                speak(answer);
            }
        }, 120);
    }

    void cancelTimer() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
        TimerAlarmReceiver.cancel(this);
    }

    void startTimer(long durationMillis) {
        if (durationMillis <= 0L) return;
        if (timer != null) timer.cancel();
        TimerAlarmReceiver.schedule(this, durationMillis);
        timer = new CountDownTimer(durationMillis, Math.min(1000L, durationMillis)) {
            @Override public void onTick(long millisUntilFinished) { }
            @Override public void onFinish() {
                String message = "Timer poora ho gaya!";
                setMessage(message);
                speak(message);
            }
        }.start();
    }

    private void speak(String text) {
        if (ttsReady && tts != null && text != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bluey-response");
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Bluey Buddy floating assistant", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shown while the Bluey Buddy floating orb is active.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int pendingFlags = android.app.PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) pendingFlags |= android.app.PendingIntent.FLAG_IMMUTABLE;
        android.app.PendingIntent content = android.app.PendingIntent.getActivity(this, 2108, open, pendingFlags);

        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        android.app.PendingIntent stopAction = android.app.PendingIntent.getService(this, 2109, stop, pendingFlags);

        return builder.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Bluey Buddy is active")
                .setContentText("Tap the blue orb to open the assistant.")
                .setContentIntent(content)
                .setOngoing(true)
                .addAction(R.drawable.ic_notification, "Stop", stopAction)
                .build();
    }

    private GradientDrawable roundRect(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(radius);
        if (strokeWidth > 0) bg.setStroke(strokeWidth, strokeColor);
        return bg;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onDestroy() {
        if (timer != null) timer.cancel();
        if (recognizer != null) {
            recognizer.cancel();
            recognizer.destroy();
            recognizer = null;
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        hidePill();
        if (orbView != null) {
            try { windowManager.removeView(orbView); } catch (Exception ignored) { }
            orbView = null;
        }
        super.onDestroy();
    }

    private final class BuddyRecognitionListener implements RecognitionListener {
        @Override public void onReadyForSpeech(android.os.Bundle params) { }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float rmsdB) { }
        @Override public void onBufferReceived(byte[] buffer) { }
        @Override public void onEndOfSpeech() { if (micButton != null) micButton.setText("Processing…"); }
        @Override public void onError(int error) {
            if (micButton != null) micButton.setText("🎙  DABAKAR BOLEIN");
            String msg = error == SpeechRecognizer.ERROR_NO_MATCH
                    ? "Awaaz samajh nahi aayi. Thoda paas se aur saaf bolkar dobara try karein."
                    : "Voice recognition ruk gayi. Microphone, internet ya offline language pack check karein.";
            setMessage(msg);
        }
        @Override public void onResults(android.os.Bundle results) {
            ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (matches != null && !matches.isEmpty()) handleRecognizedText(matches.get(0));
            else setMessage("Command samajh nahi aayi. Dobara boliye.");
        }
        @Override public void onPartialResults(android.os.Bundle partialResults) { }
        @Override public void onEvent(int eventType, android.os.Bundle params) { }
    }

    private final class OrbView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float downX, downY;
        private int startWindowX, startWindowY;
        private boolean dragged;

        OrbView() { super(OverlayService.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float radius = Math.min(w, h) * 0.43f;

            paint.setShader(new RadialGradient(cx * 0.72f, cy * 0.62f, radius * 1.55f,
                    new int[]{Color.rgb(157, 222, 255), Color.rgb(43, 143, 238), Color.rgb(15, 77, 168)},
                    null, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, radius, paint);
            paint.setShader(null);
            paint.setColor(0x557FFFFF);
            canvas.drawCircle(cx - radius * 0.25f, cy - radius * 0.35f, radius * 0.19f, paint);

            // Simple expressive blinking eyes and a tiny smile.
            long blinkPhase = System.currentTimeMillis() % 5200L;
            boolean blink = blinkPhase < 240L;
            paint.setColor(Color.WHITE);
            if (blink) {
                paint.setStrokeWidth(dp(2));
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawLine(cx - radius * 0.42f, cy - radius * 0.06f,
                        cx - radius * 0.13f, cy - radius * 0.06f, paint);
                canvas.drawLine(cx + radius * 0.13f, cy - radius * 0.06f,
                        cx + radius * 0.42f, cy - radius * 0.06f, paint);
                paint.setStyle(Paint.Style.FILL);
            } else {
                canvas.drawCircle(cx - radius * 0.27f, cy - radius * 0.10f, radius * 0.15f, paint);
                canvas.drawCircle(cx + radius * 0.27f, cy - radius * 0.10f, radius * 0.15f, paint);
                paint.setColor(Color.rgb(14, 54, 97));
                canvas.drawCircle(cx - radius * 0.25f, cy - radius * 0.08f, radius * 0.075f, paint);
                canvas.drawCircle(cx + radius * 0.25f, cy - radius * 0.08f, radius * 0.075f, paint);
            }
            paint.setColor(Color.WHITE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            canvas.drawArc(cx - radius * 0.22f, cy + radius * 0.03f,
                    cx + radius * 0.22f, cy + radius * 0.40f, 10, 160, false, paint);
            paint.setStyle(Paint.Style.FILL);
            long nextFrame = blink ? 40L : Math.max(40L, Math.min(300L, 5200L - blinkPhase));
            postInvalidateDelayed(nextFrame);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getRawX();
                    downY = event.getRawY();
                    startWindowX = orbParams.x;
                    startWindowY = orbParams.y;
                    dragged = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - downX;
                    float dy = event.getRawY() - downY;
                    if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) dragged = true;
                    if (dragged) {
                        orbParams.x = Math.max(0, startWindowX + (int) dx);
                        int maxY = Math.max(dp(8), getResources().getDisplayMetrics().heightPixels - getHeight() - dp(8));
                        orbParams.y = Math.min(maxY, Math.max(dp(8), startWindowY + (int) dy));
                        try { windowManager.updateViewLayout(orbView, orbParams); } catch (Exception ignored) { }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!dragged) showPill();
                    else {
                        // Dock to the nearest screen edge after dragging.
                        int width = getResources().getDisplayMetrics().widthPixels;
                        orbParams.x = orbParams.x + dp(33) < width / 2 ? dp(4)
                                : Math.max(0, width - getWidth() - dp(4));
                        try { windowManager.updateViewLayout(orbView, orbParams); } catch (Exception ignored) { }
                    }
                    performClick();
                    return true;
            }
            return true;
        }

        @Override public boolean performClick() { super.performClick(); return true; }
    }
}
