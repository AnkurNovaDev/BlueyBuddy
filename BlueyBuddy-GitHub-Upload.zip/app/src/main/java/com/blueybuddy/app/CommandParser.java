package com.blueybuddy.app;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pure-Java parsers for offline commands. Kept Android-free so unit tests can exercise it. */
final class CommandParser {
    private static final Map<String, Integer> NUMBER_WORDS = new HashMap<>();
    private static final Pattern DURATION = Pattern.compile(
            "(?<![\\p{L}\\p{M}\\d])([0-9]{1,4}|[\\p{L}\\p{M}]+)\\s*(hours?|hrs?|hr|h|घंटे|घंटा|minutes?|mins?|min|m|मिनट|seconds?|secs?|sec|s|सेकंड|सेकण्ड)(?![\\p{L}\\p{M}])",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern MATH = Pattern.compile(
            "(-?[0-9]+(?:\\.[0-9]+)?)\\s*(plus|add|जोड़|जमा|\\+|minus|subtract|घटाना|माइनस|-|times|multiply|गुना|गुणा|\\*|x|×|divide|divided by|भाग|\\/)\\s*(-?[0-9]+(?:\\.[0-9]+)?)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    static {
        addNumbers(0, "zero", "shunya", "शून्य");
        addNumbers(1, "one", "ek", "एक");
        addNumbers(2, "two", "do", "दो");
        addNumbers(3, "three", "teen", "तीन");
        addNumbers(4, "four", "char", "chaar", "चार");
        addNumbers(5, "five", "paanch", "panch", "पांच", "पाँच");
        addNumbers(6, "six", "chhe", "छह", "छे");
        addNumbers(7, "seven", "saat", "सात");
        addNumbers(8, "eight", "aath", "आठ");
        addNumbers(9, "nine", "nau", "नौ");
        addNumbers(10, "ten", "das", "दस");
        addNumbers(15, "fifteen", "पंद्रह");
        addNumbers(20, "twenty", "बीस");
        addNumbers(30, "thirty", "तीस");
        addNumbers(60, "sixty", "साठ");
    }

    private CommandParser() { }

    static long parseTimerMillis(String input) {
        if (input == null) return -1L;
        String normalized = normalizeDigits(input.toLowerCase(Locale.ROOT));
        Matcher matcher = DURATION.matcher(normalized);
        if (!matcher.find()) return -1L;

        long amount;
        try {
            String token = matcher.group(1);
            amount = token.matches("[0-9]+") ? Long.parseLong(token)
                    : NUMBER_WORDS.getOrDefault(token, -1);
        } catch (NumberFormatException e) {
            return -1L;
        }
        if (amount <= 0L || amount > 1440L) return -1L;

        String unit = matcher.group(2).toLowerCase(Locale.ROOT);
        long multiplier;
        if (unit.startsWith("h") || unit.contains("घंट")) multiplier = 60L * 60L * 1000L;
        else if (unit.startsWith("m") || unit.equals("मिनट")) multiplier = 60L * 1000L;
        else multiplier = 1000L;

        if (amount > Long.MAX_VALUE / multiplier) return -1L;
        long duration = amount * multiplier;
        return duration <= 24L * 60L * 60L * 1000L ? duration : -1L;
    }

    static String calculate(String input) {
        if (input == null) return null;
        Matcher matcher = MATH.matcher(normalizeDigits(input));
        if (!matcher.find()) return null;
        try {
            BigDecimal left = new BigDecimal(matcher.group(1));
            BigDecimal right = new BigDecimal(matcher.group(3));
            String operator = matcher.group(2).toLowerCase(Locale.ROOT);
            BigDecimal result;
            if (operator.equals("+") || operator.equalsIgnoreCase("plus")
                    || operator.equalsIgnoreCase("add") || operator.equals("जोड़") || operator.equals("जमा")) {
                result = left.add(right);
            } else if (operator.equals("-") || operator.equalsIgnoreCase("minus")
                    || operator.equalsIgnoreCase("subtract") || operator.equals("घटाना") || operator.equals("माइनस")) {
                result = left.subtract(right);
            } else if (operator.equals("*") || operator.equalsIgnoreCase("x") || operator.equals("×")
                    || operator.equalsIgnoreCase("times") || operator.equalsIgnoreCase("multiply")
                    || operator.equals("गुना") || operator.equals("गुणा")) {
                result = left.multiply(right);
            } else {
                if (right.compareTo(BigDecimal.ZERO) == 0) return "Zero se divide nahi kar sakte.";
                result = left.divide(right, 6, RoundingMode.HALF_UP);
            }
            return result.stripTrailingZeros().toPlainString();
        } catch (ArithmeticException | NumberFormatException e) {
            return null;
        }
    }

    private static void addNumbers(int value, String... words) {
        for (String word : words) NUMBER_WORDS.put(word.toLowerCase(Locale.ROOT), value);
    }

    private static String normalizeDigits(String text) {
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c >= '\u0966' && c <= '\u096F') out.append((char) ('0' + (c - '\u0966')));
            else out.append(c);
        }
        return out.toString();
    }
}
