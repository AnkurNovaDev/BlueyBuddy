package com.blueybuddy.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Offline-first command router. Only explicit search / unknown questions open a browser. */
public final class AssistantCommands {
    private AssistantCommands() { }

    public static String execute(OverlayService service, String raw) {
        if (raw == null || raw.trim().isEmpty()) return "Mujhe command sunai nahi di. Dobara boliye.";
        String command = raw.trim();
        String lower = command.toLowerCase(Locale.ROOT);

        if (containsAny(lower, "what time", "time batao", "tell me the time", "time kya", "samay", "kitne baje", "समय", "कितने बजे")) {
            return "Abhi " + new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date()) + " baj rahe hain.";
        }
        if (containsAny(lower, "date", "today", "tareekh", "aaj ki date", "तारीख", "आज की तारीख")) {
            return "Aaj " + new SimpleDateFormat("EEEE, d MMMM yyyy", new Locale("hi", "IN")).format(new Date()) + " hai.";
        }

        if (containsAny(lower, "cancel timer", "stop timer", "timer band", "टाइमर बंद")) {
            service.cancelTimer();
            return "Timer cancel kar diya.";
        }

        if (isTimerCommand(lower)) {
            long millis = CommandParser.parseTimerMillis(lower);
            if (millis <= 0) return "Timer ka samay samajh nahi aaya. Jaise ‘5 minute ka timer’ ya ‘paanch minute timer’ boliye.";
            service.startTimer(millis);
            return "Theek hai, timer shuru kar diya: " + humanDuration(millis) + ".";
        }

        if (containsAny(lower, "scroll down", "neeche scroll", "नीचे स्क्रॉल", "नीचे जाओ")) {
            boolean ok = BuddyAccessibilityService.scroll(true);
            return ok ? "Neeche scroll kar diya." : accessibilityHint();
        }
        if (containsAny(lower, "scroll up", "upar scroll", "ऊपर स्क्रॉल", "ऊपर जाओ")) {
            boolean ok = BuddyAccessibilityService.scroll(false);
            return ok ? "Upar scroll kar diya." : accessibilityHint();
        }
        if (containsAny(lower, "copy", "कॉपी")) {
            return BuddyAccessibilityService.copySelection() ? "Selected text copy ho gaya." : "Text select karke dobara Copy boliye. " + accessibilityHint();
        }
        if (containsAny(lower, "paste", "पेस्ट")) {
            return BuddyAccessibilityService.pasteClipboard() ? "Clipboard ka text paste kar diya." : accessibilityHint();
        }
        if (containsAny(lower, "go back", "back", "peeche jao", "वापस जाओ")) {
            return BuddyAccessibilityService.goBack() ? "Peeche aa gaya." : accessibilityHint();
        }
        if (containsAny(lower, "go home", "home screen", "ghar jao", "होम स्क्रीन")) {
            return BuddyAccessibilityService.goHome() ? "Home screen khol di." : accessibilityHint();
        }

        String typed = extractPayload(command, lower,
                new String[]{"type ", "write ", "likho ", "लिखो ", "टाइप करो ", "type karo "});
        if (typed != null) {
            boolean ok = BuddyAccessibilityService.typeIntoFocusedField(typed);
            return ok ? "Text focused field mein daal diya." : accessibilityHint();
        }

        String appName = extractPayload(command, lower,
                new String[]{"open ", "launch ", "kholo ", "khol do ", "ओपन ", "खोलो ", "खोल दो "});
        if (appName != null) return openInstalledApp(service, appName);

        String calculation = CommandParser.calculate(lower);
        if (calculation != null) return calculation.equals("Zero se divide nahi kar sakte.")
                ? calculation : "Jawab " + calculation + " hai.";

        String search = extractPayload(command, lower,
                new String[]{"search for ", "search ", "google ", "dhundo ", "khojo ", "खोजो ", "सर्च ", "search karo "});
        if (search != null) {
            openSearch(service, search);
            return "Browser mein search khol raha hoon: " + search;
        }

        if (containsAny(lower, "hello", "hi bluey", "namaste", "नमस्ते", "हेलो")) {
            return "Namaste! Main Bluey Buddy hoon. Aap app kholne, time, date, timer, calculation, search, typing ya scroll ke liye bol sakte hain.";
        }

        openSearch(service, command);
        return "Iska jawab dhoondhne ke liye browser search khol raha hoon. Is command ke liye internet lag sakta hai.";
    }

    static long parseTimerMillis(String lower) { return CommandParser.parseTimerMillis(lower); }

    private static String accessibilityHint() {
        return "Is action ke liye phone Settings mein Bluey Buddy ka Accessibility Service ON karein, aur sahi input field select rakhein.";
    }

    private static boolean containsAny(String value, String... terms) {
        for (String term : terms) if (value.contains(term)) return true;
        return false;
    }

    private static String extractPayload(String original, String lower, String[] prefixes) {
        for (String prefix : prefixes) {
            int at = lower.indexOf(prefix);
            if (at >= 0) {
                String payload = original.substring(at + prefix.length()).trim();
                if (!payload.isEmpty()) return payload;
            }
        }
        return null;
    }

    private static boolean isTimerCommand(String lower) {
        return lower.contains("timer") || lower.contains("alarm") || lower.contains("टाइमर");
    }

    static String humanDuration(long millis) {
        long seconds = millis / 1000L;
        if (seconds >= 3600) {
            long hours = seconds / 3600;
            long minutes = (seconds % 3600) / 60;
            return hours + " ghante" + (minutes > 0 ? " " + minutes + " minute" : "");
        }
        if (seconds >= 60) {
            long minutes = seconds / 60;
            long extraSeconds = seconds % 60;
            return minutes + " minute" + (extraSeconds > 0 ? " " + extraSeconds + " second" : "");
        }
        return seconds + " second";
    }

    private static void openSearch(Context context, String query) {
        try {
            Uri uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query));
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception ignored) { }
    }

    private static String openInstalledApp(Context context, String spokenName) {
        String target = spokenName.toLowerCase(Locale.ROOT).trim();
        PackageManager pm = context.getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        for (ApplicationInfo info : apps) {
            CharSequence label;
            try { label = pm.getApplicationLabel(info); } catch (Exception e) { continue; }
            if (label != null) {
                String name = label.toString().toLowerCase(Locale.ROOT);
                if (name.equals(target) || (target.length() >= 3 && name.startsWith(target))) {
                    Intent launch = pm.getLaunchIntentForPackage(info.packageName);
                    if (launch != null) {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        try {
                            context.startActivity(launch);
                            return label + " khol diya.";
                        } catch (Exception ignored) { }
                    }
                }
            }
        }

        String[][] aliases = {
                {"chrome", "com.android.chrome"}, {"youtube", "com.google.android.youtube"},
                {"whatsapp", "com.whatsapp"}, {"settings", "com.android.settings"},
                {"camera", "com.android.camera2"}, {"calculator", "com.google.android.calculator"},
                {"phone", "com.android.dialer"}, {"contacts", "com.android.contacts"},
                {"messages", "com.android.messaging"}, {"play store", "com.android.vending"}
        };
        for (String[] alias : aliases) {
            if (target.contains(alias[0])) {
                Intent launch = pm.getLaunchIntentForPackage(alias[1]);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        context.startActivity(launch);
                        return alias[0] + " khol diya.";
                    } catch (Exception ignored) { }
                }
            }
        }
        return "‘" + spokenName + "’ naam ka installed app nahi mila. App ka exact naam boliye ya ‘search for …’ kahiye.";
    }
}
