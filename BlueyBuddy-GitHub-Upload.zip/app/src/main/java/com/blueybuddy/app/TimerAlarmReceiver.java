package com.blueybuddy.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Posts a timer notification even if Android has recreated or stopped the floating service. */
public class TimerAlarmReceiver extends BroadcastReceiver {
    private static final String ACTION_FINISH = "com.blueybuddy.app.action.TIMER_FINISHED";
    private static final String PREFS = "bluey_timer_v1";
    private static final String KEY_DEADLINE = "deadline_millis";
    private static final String CHANNEL_ID = "bluey_buddy_timer";
    private static final int REQUEST_CODE = 7132;
    private static final int NOTIFICATION_ID = 7132;

    public static void schedule(Context context, long durationMillis) {
        if (durationMillis <= 0L) return;
        long deadline = System.currentTimeMillis() + durationMillis;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putLong(KEY_DEADLINE, deadline).commit();

        scheduleAt(context, deadline);
    }

    private static void scheduleAt(Context context, long deadline) {
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pending = pendingIntent(context);
        if (alarms == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, deadline, pending);
            } else {
                alarms.setExact(AlarmManager.RTC_WAKEUP, deadline, pending);
            }
        } catch (SecurityException ex) {
            // Compatibility fallback for devices that restrict exact alarms.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, deadline, pending);
            } else {
                alarms.set(AlarmManager.RTC_WAKEUP, deadline, pending);
            }
        }
    }

    public static long getDeadline(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getLong(KEY_DEADLINE, 0L);
    }

    public static void cancel(Context context) {
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms != null) alarms.cancel(pendingIntent(context));
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().remove(KEY_DEADLINE).commit();
    }

    public static void rescheduleAfterBoot(Context context) {
        long savedDeadline = getDeadline(context);
        if (savedDeadline <= 0L) return;
        if (savedDeadline > System.currentTimeMillis()) scheduleAt(context, savedDeadline);
        else {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().remove(KEY_DEADLINE).commit();
            showFinishedNotification(context);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !ACTION_FINISH.equals(intent.getAction())) return;
        long deadline = getDeadline(context);
        if (deadline <= 0L) return;
        if (System.currentTimeMillis() + 1500L < deadline) {
            // Re-arm in case the system delivered an inexact fallback early.
            scheduleAt(context, deadline);
            return;
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().remove(KEY_DEADLINE).commit();
        showFinishedNotification(context);
    }

    private static PendingIntent pendingIntent(Context context) {
        Intent intent = new Intent(context, TimerAlarmReceiver.class).setAction(ACTION_FINISH);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags);
    }

    private static void showFinishedNotification(Context context) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Bluey Buddy timer", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Timer completion alerts from Bluey Buddy.");
            manager.createNotificationChannel(channel);
        }
        Intent open = new Intent(context, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent content = PendingIntent.getActivity(context, REQUEST_CODE, open, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL_ID) : new Notification.Builder(context);
        Notification notification = builder
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Bluey Buddy")
                .setContentText("Aapka timer poora ho gaya!")
                .setContentIntent(content)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE)
                .build();
        manager.notify(NOTIFICATION_ID, notification);
    }
}
