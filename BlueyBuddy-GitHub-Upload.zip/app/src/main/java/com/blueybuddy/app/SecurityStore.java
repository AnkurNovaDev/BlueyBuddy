package com.blueybuddy.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Local owner PIN storage. The raw PIN is never written to preferences. */
public final class SecurityStore {
    private static final String PREFS = "bluey_security_v1";
    private static final String KEY_SALT = "pin_salt";
    private static final String KEY_HASH = "pin_hash";
    private static final String KEY_LOG = "failed_unlock_log";
    private static final String KEY_FAILURE_COUNT = "failure_count";
    private static final String KEY_LOCKED_UNTIL = "locked_until";
    private static final int ITERATIONS = 80000;
    private static final int KEY_BITS = 256;

    private SecurityStore() { }

    public static boolean hasPin(Context context) {
        SharedPreferences p = prefs(context);
        return p.contains(KEY_SALT) && p.contains(KEY_HASH);
    }

    public static boolean savePin(Context context, String pin) {
        if (pin == null || !pin.matches("[0-9]{4,8}")) return false;
        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            byte[] hash = derive(pin.toCharArray(), salt);
            prefs(context).edit()
                    .putString(KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
                    .putString(KEY_HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
                    .apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean verifyPin(Context context, String pin) {
        if (pin == null || !pin.matches("[0-9]{4,8}")) return false;
        try {
            SharedPreferences p = prefs(context);
            String saltText = p.getString(KEY_SALT, null);
            String hashText = p.getString(KEY_HASH, null);
            if (saltText == null || hashText == null) return false;
            byte[] salt = Base64.decode(saltText, Base64.NO_WRAP);
            byte[] expected = Base64.decode(hashText, Base64.NO_WRAP);
            byte[] actual = derive(pin.toCharArray(), salt);
            return MessageDigest.isEqual(expected, actual);
        } catch (Exception e) {
            return false;
        }
    }

    public static void recordFailedAttempt(Context context) {
        SharedPreferences p = prefs(context);
        int failures = p.getInt(KEY_FAILURE_COUNT, 0) + 1;
        long lockDuration;
        if (failures >= 12) lockDuration = 15 * 60 * 1000L;
        else if (failures >= 8) lockDuration = 5 * 60 * 1000L;
        else if (failures >= 5) lockDuration = 30 * 1000L;
        else if (failures >= 3) lockDuration = 10 * 1000L;
        else lockDuration = 0L;
        String current = p.getString(KEY_LOG, "");
        String stamp = new SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault())
                .format(new Date());
        String[] old = current.isEmpty() ? new String[0] : current.split("\\n");
        StringBuilder out = new StringBuilder(stamp);
        int kept = 0;
        for (String line : old) {
            if (!line.trim().isEmpty() && kept < 9) {
                out.append('\n').append(line);
                kept++;
            }
        }
        SharedPreferences.Editor editor = p.edit().putString(KEY_LOG, out.toString())
                .putInt(KEY_FAILURE_COUNT, failures);
        if (lockDuration > 0) editor.putLong(KEY_LOCKED_UNTIL, System.currentTimeMillis() + lockDuration);
        editor.apply();
    }

    public static boolean isLockedOut(Context context) {
        return prefs(context).getLong(KEY_LOCKED_UNTIL, 0L) > System.currentTimeMillis();
    }

    public static long getLockoutRemainingMillis(Context context) {
        return Math.max(0L, prefs(context).getLong(KEY_LOCKED_UNTIL, 0L) - System.currentTimeMillis());
    }

    public static void recordSuccessfulVerification(Context context) {
        prefs(context).edit().remove(KEY_FAILURE_COUNT).remove(KEY_LOCKED_UNTIL).apply();
    }

    public static List<String> getFailedAttempts(Context context) {
        String value = prefs(context).getString(KEY_LOG, "");
        List<String> result = new ArrayList<>();
        if (value != null && !value.trim().isEmpty()) {
            for (String line : value.split("\\n")) result.add(line);
        }
        return result;
    }

    private static byte[] derive(char[] pin, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pin, salt, ITERATIONS, KEY_BITS);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
        } finally {
            spec.clearPassword();
        }
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
