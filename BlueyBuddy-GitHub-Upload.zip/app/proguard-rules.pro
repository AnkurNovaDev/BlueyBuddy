# No custom shrinker rules are needed for the current build.
