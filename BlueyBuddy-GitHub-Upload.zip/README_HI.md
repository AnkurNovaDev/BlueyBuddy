# Bluey Buddy — Android project (source revision 1.1.0)

Bluey Buddy ek floating blue orb assistant hai, Oppo A3s / Android 8.1 (API 27) ko dhyan mein rakhkar. Project mein app-side AI API key ya cloud account nahi hai. Basic phone commands aur arithmetic phone par route hote hain; speech provider aur browser search ke apne network/offline requirements ho sakte hain.

## Source mein included functionality

- Floating blue orb, animated blink/smile, drag aur nearest-edge docking.
- Orb tap par top pill morph; press-and-hold mic interaction.
- Android 12+ par on-device SpeechRecognizer availability ho to on-device provider; Android 8.1 jaise purane versions par standard SpeechRecognizer + `EXTRA_PREFER_OFFLINE` request.
- Installed Android Text-to-Speech engine se spoken replies.
- Installed apps launch (label matching + common aliases).
- Local date/time, timer start/cancel, basic arithmetic (plus/minus/times/divide).
- Browser/Google search.
- Accessibility-based focused-field typing, selected-text copy, clipboard paste, scroll up/down, Back aur Home.
- Owner PIN ka salted PBKDF2 hash, supported Android system biometric prompt, failed-attempt timestamps aur local lockout. Oppo A3s mein fingerprint sensor nahi hai; isliye is device par PIN fallback primary method hoga.
- AlarmManager-based timer completion notification; floating service active ho to voice announcement bhi. BootReceiver saved deadline ko reboot ke baad reschedule karta hai; real-device reboot test pending hai.
- Visible foreground-service notification with Stop action.
- Unit tests for pure-Java timer/math command parsing.

**Important:** Source mein feature hona, Android build pass hona, aur Oppo phone par feature ka sahi chalna teen alag checks hain. Current status `IMPLEMENTATION_STATUS_HI.md` mein diya hai.

## Oppo A3s setup

1. GitHub Actions se `BlueyBuddy-debug-apk` artifact banne ke baad `app-debug.apk` install karein. Debug application ID `com.blueybuddy.app.debug` hai.
2. App kholkar owner PIN set karein. Floating service start karne se pehle PIN ya available system biometric verification hoti hai.
3. `ALLOW DISPLAY OVER OTHER APPS` par jaakar permission ON karein.
4. Microphone permission allow karein.
5. `ENABLE PHONE CONTROLS` kholkar Android Accessibility settings mein `Bluey Buddy phone controls` manually ON karein. Ye optional phone-control features ke liye hai.
6. `START FLOATING BLUEY` dabayein. Orb screen par dikhna chahiye.
7. Orb tap karein, phir mic button dabakar command bolein; bolna khatam karke button chhod dein.

ColorOS battery saver/background restrictions foreground service ko band kar sakte hain. Isliye device par long-run test zaroori hai.

## Voice examples

- `Open WhatsApp`, `Open YouTube`, `Open Settings`
- `Time batao`, `Aaj ki date`
- `5 minute ka timer`, `paanch minute timer`, `cancel timer`
- `2 plus 3`, `10 minus 4`, `6 times 7`, `8 divide 2`
- `Search for ...`, `Google ...`
- `Type hello` — pehle target app ka normal editable field focus karein.
- `Copy`, `Paste`, `Scroll down`, `Scroll up`, `Back`, `Home`

## Privacy and real-world limits

1. **Offline voice guaranteed nahi:** SpeechRecognizer ko offline preference di jaati hai, lekin actual offline Hindi recognition installed speech provider/model par depend karta hai.
2. **Wake word nahi:** Always-on “Hey Bluey” listening is build mein included nahi. Mic sirf user ke manual press-and-hold se start hota hai.
3. **Full offline AI nahi:** Local parser supported commands/basic arithmetic karta hai; general-purpose LLM bundled nahi hai. Unsupported questions browser search mein khul sakte hain.
4. **Timer behavior:** Pending timer reboot ke baad restore karne ka receiver included hai; actual ColorOS battery policy ke saath test zaroori hai.
5. **Accessibility limits:** Secure/password inputs block kiye gaye hain. Custom app UI copy/paste/scroll/type actions reject kar sakti hai.
5. **Face verification:** OPPO A3s mein fingerprint sensor nahi hai aur built-in ColorOS Face Unlock hai. Is app ka standard AndroidX biometric prompt us proprietary face feature ko reliably access nahi karta; app-integrated face matching included nahi hai. PIN fallback use karein.
6. **Failed attempt photos:** Hidden camera capture intentionally nahi hai; local timestamp log hota hai.
7. **Timer:** Alarm receiver service/process ke rukne par bhi notification de sakta hai. BootReceiver reboot ke baad saved deadline reschedule karta hai, lekin Oppo/ColorOS par reboot aur battery restrictions ka test karna zaroori hai.

## Build configuration

- JDK 17
- Android SDK Platform 35 + Build Tools 35.0.0
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- Minimum API 27; target API 28 for Android 8.1 compatibility.

Project mein Gradle wrapper JAR include nahi hai. CI workflow Gradle 8.7 set up karta hai aur ye command chalata hai:

```bash
gradle --no-daemon --stacktrace clean testDebugUnitTest lintDebug assembleDebug
```

APK path:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Debug APK direct testing ke liye hai; Play Store release signing configure nahi hai.
